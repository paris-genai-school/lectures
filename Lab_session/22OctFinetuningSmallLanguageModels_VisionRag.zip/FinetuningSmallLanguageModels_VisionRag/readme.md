Practical Tuesday Afternoon


These notebook aims to give a quick overview of modern finetuning techniques on lower end GPUs & some instruction model applications. 
The goal is NOT to reinvent the wheel, but rather give an overview of several current libs and good practices. Lots of concepts are in there - these notebooks do not aim to explain them. This is what the TAs are for, and Google can help too !


They touch up on several key concepts:


1.  Instruction Fine-tuning a SLM (Part 1)
  *  Base vs Instruct/Chat models
  *  LoRA Adapters
  *  Unsloth
  *  Quantization
  *  Chat templating and data preparation
  *  SFTTrainers
  *  Going further: Preparing your own finetuning dataset through synthetic data generation.


2. Retrieval Augmented Generation with Vision Language Models (Part 2)
  * Vision Language Models (Qwen2-VL)
  * ColPali
  * RAG
  * API calls


These notebooks are inspired by ressources from Unsloth AI & Manuel Faysse.
You can do both, or choose one, they are independant of one another !


Running the notebooks:


Option 1: You can run through HFactory:
Click on the compute icon on the top rightStart an instance (V100 Lite is recommended by the school)Navigate to Courses and select Tuesday Practicals


Option 2: You can run in Google Colab:
Download and upload the ipynb file in Google Colab where you can get a free GPUYou can also click on this link:  Part 1 .  Part 2  Then, click "Save a copy in Drive" and work on your own version.Make sure you have a GPU (runtime --> change runtime type)


Option 3: You have the .ipynb file
Feel free to do your own thing if you prefer and have GPU access
