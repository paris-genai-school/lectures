Hello and welcome to this practical session about RLHF.

﻿

We will mostly focus on offline alignment algorithms such as DPO, since they are more computationally efficient. It is also not difficult to turn them into online algorithms.

﻿
This session is split into two parts:

﻿

Part I: Investigation in the tabular case

In Part I, we will focus on a better theoretical understanding of the algorithms. To this end, we will play with mostly "tabular" settings with there is no language model and we just define everything as distributions over categorical variables.

We will illustrate properties of offline optimization using tabular experiments that echo with our discussions in the theoretical section.

﻿

Part II: Training a small transformer using SFT and DPO

In Part II, we will familiarize ourselves with the stack related to training full transformer models. We will load a GPT-2 model and train it with synthetic SFT and DPO data. ﻿ 

﻿

This section is heavily inspired by Andrej Karpathy's nano-GPT series. I encourage to check it as it is a great place to learn the basics of transformers in general.

﻿